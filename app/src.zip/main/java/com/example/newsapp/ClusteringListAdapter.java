package com.example.newsapp;
import android.annotation.SuppressLint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class ClusteringListAdapter extends RecyclerView.Adapter<ClusteringListAdapter.ClusteringListViewHolder> {
    List<EventClusterEntity> eventlist;

    static public class ClusteringListViewHolder extends RecyclerView.ViewHolder {
        public ConstraintLayout layout;
        public ClusteringListViewHolder(ConstraintLayout v) {
            super(v);
            layout = v;
        }
    }
    ClusteringListAdapter() { eventlist = new ArrayList<>(); }
    ClusteringListAdapter(int type){
        eventlist=new ArrayList<>();
        eventlist.addAll(EventsClusterDataFetcher.fetchDataFromMem(type));
    }
    @NotNull
    @Override
    public ClusteringListAdapter.ClusteringListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ConstraintLayout v = (ConstraintLayout) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.single_event_layout, parent, false);
        return new ClusteringListViewHolder(v);
    }
    @SuppressLint("ResourceAsColor")
    @Override
    public void onBindViewHolder(ClusteringListViewHolder holder, int position) {
        Log.d("position", String.valueOf(position));
        TextView eventTextView = holder.layout.findViewById(R.id.event_title);
        TextView eventSourceView = holder.layout.findViewById(R.id.event_source);
        eventTextView.setText(eventlist.get(position).title);
        eventSourceView.setText(eventlist.get(position).date);
    }
    @Override
    public int getItemCount() { return eventlist.size(); }
}
