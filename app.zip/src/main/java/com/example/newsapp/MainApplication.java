package com.example.newsapp;

import android.app.Application;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import org.litepal.LitePal;
import org.litepal.LitePalDB;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;


public class MainApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        LitePal.initialize(this);
        for(String name: this.databaseList()) {
            Log.d("MainApp", name);
        }
        Log.d("Database: ", LitePal.getDatabase().getPath());
        Thread netThread = new Thread(networkTask);
        netThread.start();
    }

    Runnable networkTask = () -> {
        //String[] dbfiles = {"demo"};
        //for(String name: dbfiles){
        //    DataBase.deleteDataBase(name);
        //}

        try {
            long startTime =  System.currentTimeMillis();
            //EpidemicDataFetcher.fetchData();

            List<NewsEntity> eventsList = EventsDataFetcher.fetchData();
            Log.d("newsNumber", String.valueOf(eventsList.size()));
            SearchEngine.init(eventsList);
            DataLoader.loadRelatedNews(eventsList.get(0).getmRelatedNews());
            DataLoader.loadRelatedNews(eventsList.get(1).getmRelatedNews());
            Log.d("search: ", SearchEngine.searchKeyWords(Arrays.asList("病毒", "武汉")).toString());
            //List<SearchEntity> searchResult = SearchEntityDataFetcher.fetchSearchEntities("病毒");
            //Log.d("main", searchResult.toString());
            //Log.d("size", String.valueOf(searchResult.size()));

            //List<SearchEntity> searchResult1 = SearchEntityDataFetcher.fetchSearchEntities("疫情");
            //Log.d("main", searchResult1.toString());
            //Log.d("size", String.valueOf(searchResult1.size()));

            //List<ExpertEntity> expertList = ExpertsDataFetcher.fetchExpertsList();
            //for(ExpertEntity expert: expertList){
            //    Log.d("main", expert.toString());
            //}
            //long endTime =  System.currentTimeMillis();
            //long usedTime = (endTime-startTime)/1000;
            //Log.d("totalTime","usedTime=" + usedTime + "s");

            //SQLiteDatabase db = LitePal.getDatabase();
            //Log.d("Main", db.getPath());

            //DataLoader.loadExpertData("钟南山");
            //DataLoader.loadExpertsDataList();
            //DataLoader.loadSearchResult("病毒");

            //DataLoader.loadCountryEpidemicData("China");
            //DataLoader.loadCountryEpidemicDataList();
            //DataLoader.loadChinaProvinceEpidemicData("mConfirmed");

        } catch (IOException e) {
            e.printStackTrace();
        }
    };
}
