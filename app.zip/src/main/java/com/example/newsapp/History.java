package com.example.newsapp;

import org.jetbrains.annotations.NotNull;
import org.litepal.crud.LitePalSupport;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;

class History extends LitePalSupport {
    public static void logHistory() { }
}

class KeyWordHistory extends History {
    private static LinkedHashSet<String> keywordHistory;

    public static void add(String keyword){
        keywordHistory.add(keyword);
    }

    public static void addAll(List<String> keywords) {
        keywordHistory.addAll(keywords);
    }

    @NotNull
    public static String[] getHistory() {
        return (String[]) keywordHistory.toArray();
    }
}

class ViewedNewsHistory extends History {
    private static LinkedHashSet<NewsEntity> newsHistory;

    public static void add(NewsEntity news){
        newsHistory.add(news);
    }

    public static void addAll(List<NewsEntity> newsList) {
        newsHistory.addAll(newsList);
    }

    @NotNull
    public static NewsEntity[] getHistory() {
        return (NewsEntity[]) newsHistory.toArray();
    }
}

class SearchedEntityHistory extends History {
    private static LinkedHashSet<SearchEntity> searchHistory;

    public static void add(SearchEntity search){
        searchHistory.add(search);
    }

    public static void addAll(List<SearchEntity> searchList) {
        searchHistory.addAll(searchList);
    }

    @NotNull
    public static SearchEntity[] getHistory() {
        return (SearchEntity[]) searchHistory.toArray();
    }
}
