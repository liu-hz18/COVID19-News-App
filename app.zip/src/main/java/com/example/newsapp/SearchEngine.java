package com.example.newsapp;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;


class Tuple<T1, T2> {
    public T1 first;
    public T2 second;
    Tuple(T1 f, T2 s) {
        first = f;
        second = s;
    }
}


public class SearchEngine {
    private static Map<String, ArrayList<Tuple<String, Double>>> invertedIndex = new HashMap<>();

    @Contract(pure = true)
    public static Map<String, ArrayList<Tuple<String, Double>>> getInvertedIndex() {
        return invertedIndex;
    }

    public static void init(@NotNull List<NewsEntity> newsList) {
        //词频统计
        Map<String, Map<String, Long> > tfTable = new HashMap<>();
        Map<String, Double> idfTable = new HashMap<>();
        //计算tf
        for(NewsEntity newsFile: newsList) {
            List<String> tokens = newsFile.getmTokens();
            Map<String, Long> countMap = tokens.parallelStream().collect(
                    Collectors.groupingBy(String::toString, Collectors.counting()));
            tfTable.put(newsFile.getmEventId(), countMap);
            countMap.keySet().forEach(token -> {
                Double idf;
                if( (idf = idfTable.get(token)) != null) {
                    idfTable.put(token, idf + 1.0);
                } else {
                    idfTable.put(token, 1.0);
                }
            });
        }
        //计算idf
        double totalFiles = newsList.size();
        idfTable.forEach((key, value) -> value = Math.log(totalFiles / (value + 1)));
        //计算tf-idf
        idfTable.forEach((key, value) -> {
            ArrayList<Tuple<String, Double>> filetfList = new ArrayList<>();
            newsList.forEach(
                    newsFile -> filetfList.add(new Tuple<String, Double>(newsFile.getmEventId(), Objects.requireNonNull(tfTable.get(newsFile.getmEventId()).get(key)).doubleValue() * value))
            );
            invertedIndex.put(key, filetfList);
        });
        //排序得到倒排索引
        invertedIndex.forEach((token, fileMap) -> {
            Collections.sort(fileMap, (Tuple<String, Double> left, Tuple<String, Double> right) -> {
                return right.second.compareTo(left.second);
            });
        });
    }

    @NotNull
    public static List<String> searchKeyWords(@NotNull List<String> keyWordsList) {
        KeyWordHistory.addAll(keyWordsList);

        Map<String, Tuple<String, Double>> fileIdValues = new HashMap<>();
        for(String keyword: keyWordsList) {
            if (invertedIndex.containsKey(keyword)) {
                for(Tuple<String, Double> tuple: invertedIndex.get(keyword)) {
                    Tuple<String, Double> newTuple;
                    if((newTuple = fileIdValues.get(tuple.first)) != null) {
                        fileIdValues.put(tuple.first, new Tuple<>(tuple.first, newTuple.second + tuple.second));
                    } else {
                        fileIdValues.put(tuple.first, tuple);
                    }
                }
            }
        }
        ArrayList<Tuple<String, Double>> ids = new ArrayList<>(fileIdValues.values());
        Collections.sort(ids, (Tuple<String, Double> left, Tuple<String, Double> right) -> {
            return right.second.compareTo(left.second);
        });
        ArrayList<String> fileIds = new ArrayList<>();
        ids.forEach(tuple -> fileIds.add(tuple.first));
        return fileIds;
    }
}
