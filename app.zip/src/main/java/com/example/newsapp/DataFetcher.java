package com.example.newsapp;

import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import org.jetbrains.annotations.NotNull;
import org.litepal.LitePal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;


class BaseDataFetcher {
    private static final String TAG = "BaseDataFetcher";
    static JSONObject getJsonData(final String url_str) throws IOException {
        URL data_url = new URL(url_str);
        BufferedReader json_in = new BufferedReader(new InputStreamReader(data_url.openStream()));
        String input_json;
        StringBuilder total = new StringBuilder();
        while((input_json = json_in.readLine()) != null) {
            total.append(input_json);
        }
        json_in.close();
        return JSON.parseObject(total.toString());
    }
}

class EpidemicDataFetcher extends BaseDataFetcher {
    private static final String TAG = "EpidemicDataFetcher";
    private final static String url = "https://covid-dashboard.aminer.cn/api/dist/epidemic.json";
    private static JSONObject getEpidemicJsonData() throws IOException {
        return BaseDataFetcher.getJsonData(url);
    }

    @NotNull
    public static void fetchData() throws IOException {
        JSONObject json_obj = EpidemicDataFetcher.getEpidemicJsonData();
        for(Map.Entry entry: json_obj.entrySet()) {
            String key = entry.getKey().toString();
            String[] locationInfo = key.split("\\|");
            JSONObject value = json_obj.getJSONObject(key);
            JSONArray dataArr = value.getJSONArray("data");
            Log.d("last", dataArr.get(dataArr.size()-1).toString() + key + " ");
            List<Integer> data = Converter.StringListToList(dataArr.get(dataArr.size()-1).toString(), ",", 4);
            switch (locationInfo.length){
                case 1:
                    CountryEpidemicEntity countryData = new CountryEpidemicEntity(key, value.getString("begin"), data);
                    countryData.save();
                    break;
                case 2:
                    if (locationInfo[0].equals("China")){
                        ChinaProvinceEpidemicEntity provinceData = new ChinaProvinceEpidemicEntity(key, value.getString("begin"), data);
                        provinceData.save();
                    }
                    break;
                default:
                    break;
            }
        }
    }
}

class EventsDataFetcher extends BaseDataFetcher {
    private static final String TAG = "EventsDataFetcher";
    private final static String url = "https://covid-dashboard.aminer.cn/api/dist/events.json";
    private static JSONObject getEventsJsonData() throws IOException {
        return BaseDataFetcher.getJsonData(url);
    }

    @NotNull
    public static List<NewsEntity> fetchData() throws IOException {
        JSONArray eventsArray = getEventsJsonData().getJSONArray("datas");
        List<NewsEntity> eventsList = new ArrayList<>();
        eventsArray.parallelStream().forEach(
                jsonObj -> EventsDataFetcher.addEventToList((JSONObject) jsonObj, eventsList)
        );
        LitePal.saveAll(eventsList);
        return eventsList;
    }

    private static void addEventToList(JSONObject jsonObj, @NotNull List<NewsEntity> eventsList) {
        if(jsonObj == null) return;
        NewsEntity event = new NewsEntity(
                jsonObj.getString("_id"),
                jsonObj.getString("type"),
                jsonObj.getString("title"),
                jsonObj.getString("category"),
                jsonObj.getString("time"),
                jsonObj.getString("lang")
        );
        synchronized (EventsDataFetcher.class) {
            eventsList.add(event);
        }
    }
}

class SearchEntityDataFetcher extends BaseDataFetcher {
    private static final String TAG = "SearchEntityDataFetcher";
    private final static String url = "https://innovaapi.aminer.cn/covid/api/v1/pneumonia/entityquery?entity=";

    public static JSONObject getSearchEntityJsonData(final String keyword) throws IOException {
        return BaseDataFetcher.getJsonData(url + keyword);
    }

    @NotNull
    public static List<SearchEntity> fetchSearchEntities(final String keyword) throws IOException {
        List<SearchEntity> entityList = new ArrayList<>();
        JSONObject entityJson = SearchEntityDataFetcher.getSearchEntityJsonData(keyword);
        if (entityJson != null && entityJson.getJSONArray("data").size() > 0) {
            entityJson.getJSONArray("data").forEach(
                    jsonObj -> parseEntityJsonObject((JSONObject)jsonObj, entityList));
        }
        return entityList;
    }

    private static void parseEntityJsonObject(@NotNull JSONObject entityObj, List<SearchEntity> entityList) {
        JSONObject abstractInfo = entityObj.getJSONObject("abstractInfo");
        String intro = abstractInfo.getString("baidu");
        if (intro.equals("")) {
            intro = abstractInfo.getString("zhwiki");
        }
        if (intro.equals("")) {
            intro = abstractInfo.getString("enwiki");
        }
        SearchEntity entity = new SearchEntity(
                entityObj.getDouble("hot"),
                entityObj.getString("label"),
                entityObj.getString("url"),
                intro,
                entityObj.getString("img"),
                abstractInfo.getJSONObject("COVID")
        );
        entityList.add(entity);
        entity.save();
    }
}

class ExpertsDataFetcher extends BaseDataFetcher {
    private static final String TAG = "ExpertsDataFetcher";
    private final static String url = "https://innovaapi.aminer.cn/predictor/api/v1/valhalla/highlight/get_ncov_expers_list?v=2";

    private static JSONObject getExpertsJsonData() throws IOException {
        return BaseDataFetcher.getJsonData(url);
    }

    @NotNull
    public static List<ExpertEntity> fetchExpertsList() throws IOException {
        List<ExpertEntity> expertList = new ArrayList<>();
        JSONObject experts = getExpertsJsonData();
        if(experts != null) {
            JSONArray expertsArr = experts.getJSONArray("data");
            expertsArr.parallelStream().forEach(expertJson->parseExpertJsonObj((JSONObject) expertJson, expertList));
        }
        return expertList;
    }

    private static void parseExpertJsonObj(@NotNull JSONObject expertJson, @NotNull List<ExpertEntity> expertList) {
        ExpertEntity expert = new ExpertEntity(expertJson.getString("id"));
        expert.mImgURL = expertJson.getString("avatar");
        expert.mEnName = expertJson.getString("name");
        expert.mZhName = expertJson.getString("name_zh");
        if(expert.mZhName.equals("")) expert.mZhName = expert.mEnName;
        expert.hasPassedAway = expertJson.getBoolean("is_passedaway");

        JSONObject profile = expertJson.getJSONObject("profile");
        expert.mAssociation = profile.getString("affiliation") + "/" + profile.getString("affiliation_zh");
        expert.mBasicIntro = profile.getString("bio");
        if(expert.mBasicIntro != null) expert.mBasicIntro = expert.mBasicIntro.replace("<br>", "");
        expert.mEduIntro = profile.getString("edu");
        if(expert.mEduIntro != null) expert.mEduIntro = expert.mEduIntro.replace("<br>", "");
        expert.mHomePage = profile.getString("homepage");
        expert.mPosition = profile.getString("position");

        JSONObject indices = expertJson.getJSONObject("indices");
        expert.mActivityRate = indices.getDouble("activity");
        expert.mCitations = indices.getDouble("citations");
        expert.mDiversityRate = indices.getDouble("diversity");
        expert.mHindex = indices.getDouble("hindex");
        expert.mGindex = indices.getDouble("gindex");
        expert.mNewStar = indices.getDouble("newStar");
        expert.mSociability = indices.getDouble("sociability");
        expert.mPublication = indices.getInteger("pubs");
        synchronized (ExpertsDataFetcher.class){
            expertList.add(expert);
            expert.save();
        }
    }
}