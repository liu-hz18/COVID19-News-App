package com.example.newsapp;

import android.util.Log;

import org.jetbrains.annotations.NotNull;
import org.litepal.LitePal;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.acl.LastOwnerException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

class DataBase {
    public static void deleteDataBase(final String name) {
        File file = new File("/data/user/0/com.example.newsapp/databases/" + name + ".db");
        if(file.exists() && file.isFile()) {
            Log.d("delete db: ", String.valueOf(file.delete()));
        }
        File Jfile = new File("/data/user/0/com.example.newsapp/databases/" + name + ".db-journal");
        if(Jfile.exists() && Jfile.isFile()) {
            Log.d("delete db-journal: ", String.valueOf(Jfile.delete()));
        }
    }
}


//加载数据
class DataLoader {
    //public static List<NewsEntity> loadInitNews(final int number) {

    //}

    //public static List<NewsEntity> loadMoreNews(final int number) {

    //}

    //public static List<NewsEntity> loadLatestNews(final int number) {

    //}

    //public static List<NewsEntity> searchNews(final String keyword) {

    //}

    @NotNull
    public static List<NewsEntity> loadRelatedNews(@NotNull List<String> relatedNews) {
        List<NewsEntity> related = new ArrayList<>();
        for (String newsid: relatedNews) {
            related.add(LitePal.where("mEventId = ?", newsid).findFirst(NewsEntity.class));
        }
        return related;
    }

    public static List<ExpertEntity> loadExpertsDataList() {
        List<ExpertEntity> expertsData = LitePal.findAll(ExpertEntity.class);
        //Log.d("loadExpertsDataList", expertsData.toString());
        return expertsData;
    }

    @NotNull
    public static ExpertEntity loadExpertData(final String name) {
        ExpertEntity expert = LitePal
                .where("mZhName like ? or mEnName like ?", name, name)
                .findFirst(ExpertEntity.class);
        //Log.d("loadExpertData", expert.toString());
        return expert;
    }

    @NotNull
    public static SearchEntity loadSearchResult(final String keyword) {
        SearchEntity searchResult = LitePal.where("mLabel = ?", keyword)
                .findFirst(SearchEntity.class);
        //Log.d("loadSearchResult", searchResult.toString());
        return searchResult;
    }

    @NotNull
    public static List<CountryEpidemicEntity> loadCountryEpidemicDataList() {
        ArrayList<CountryEpidemicEntity> countryData = (ArrayList<CountryEpidemicEntity>) LitePal.findAll(CountryEpidemicEntity.class);
        Log.d("loadCountryEpidemicDataList", countryData.toString());
        return countryData;
    }

    @NotNull
    public static CountryEpidemicEntity loadCountryEpidemicData(final String country) {
        CountryEpidemicEntity countryData = LitePal.where("mRegion = ?", country)
                .findFirst(CountryEpidemicEntity.class);
        Log.d("loadCountryEpidemicData", countryData.toString());
        return countryData;
    }

    public static List<ChinaProvinceEpidemicEntity> loadChinaProvinceEpidemicData(String category) throws NoSuchMethodException {
        if (category == null) category = "mConfirmed";
        List<ChinaProvinceEpidemicEntity> china = LitePal.findAll(ChinaProvinceEpidemicEntity.class);
        //通过反射，可以按某个字段排序
        /*
        Class clazz = ChinaProvinceEpidemicEntity.class;
        Method method = clazz.getDeclaredMethod(category);
        Collections.sort(china, (left, right) -> {
            try {
                return ((Integer) Objects.requireNonNull(method.invoke(right)))
                        .compareTo((Integer) Objects.requireNonNull(method.invoke(left)));
            } catch (IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
                return 0;
            }
        });
         */
        return china;
    }
}


